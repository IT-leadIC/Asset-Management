from flask import Flask, render_template_string, request, redirect, url_for, session
import sqlite3
from functools import wraps

app = Flask(__name__)

DATABASE_FILE = "assets.db"

# Temporary secret key for local testing
app.secret_key = "change-this-before-public-deployment"

# Temporary admin credentials
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "AssetAdmin@2026"


def get_db():
    conn = sqlite3.connect(DATABASE_FILE)
    conn.row_factory = sqlite3.Row
    return conn


# =========================
# ADMIN LOGIN REQUIRED
# =========================
def login_required(f):

    @wraps(f)
    def decorated_function(*args, **kwargs):

        if not session.get("admin_logged_in"):
            return redirect(url_for("login"))

        return f(*args, **kwargs)

    return decorated_function


# =========================
# ADMIN LOGIN
# =========================
@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:

            session["admin_logged_in"] = True

            return redirect(url_for("admin"))

        return render_template_string("""
        <!DOCTYPE html>
        <html>
        <head>
            <meta name="viewport"
                  content="width=device-width, initial-scale=1">

            <title>Admin Login</title>

            <style>

                body {
                    font-family: Arial, sans-serif;
                    background: #f3f4f6;
                    padding: 20px;
                }

                .card {
                    max-width: 400px;
                    margin: 60px auto;
                    background: white;
                    padding: 25px;
                    border-radius: 15px;
                    box-shadow: 0 3px 12px rgba(0,0,0,0.15);
                }

                h2 {
                    text-align: center;
                }

                label {
                    display: block;
                    margin-top: 15px;
                    font-weight: bold;
                }

                input {
                    width: 100%;
                    padding: 10px;
                    margin-top: 5px;
                    box-sizing: border-box;
                }

                button {
                    width: 100%;
                    padding: 12px;
                    margin-top: 20px;
                    cursor: pointer;
                }

                .error {
                    color: red;
                    text-align: center;
                }

            </style>
        </head>

        <body>

            <div class="card">

                <h2>ADMIN LOGIN</h2>

                <p class="error">
                    Invalid username or password
                </p>

                <form method="POST">

                    <label>Username</label>

                    <input
                        type="text"
                        name="username"
                        required
                    >

                    <label>Password</label>

                    <input
                        type="password"
                        name="password"
                        required
                    >

                    <button type="submit">
                        LOGIN
                    </button>

                </form>

            </div>

        </body>
        </html>
        """)

    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>

        <meta name="viewport"
              content="width=device-width, initial-scale=1">

        <title>Admin Login</title>

        <style>

            body {
                font-family: Arial, sans-serif;
                background: #f3f4f6;
                padding: 20px;
            }

            .card {
                max-width: 400px;
                margin: 60px auto;
                background: white;
                padding: 25px;
                border-radius: 15px;
                box-shadow: 0 3px 12px rgba(0,0,0,0.15);
            }

            h2 {
                text-align: center;
            }

            label {
                display: block;
                margin-top: 15px;
                font-weight: bold;
            }

            input {
                width: 100%;
                padding: 10px;
                margin-top: 5px;
                box-sizing: border-box;
            }

            button {
                width: 100%;
                padding: 12px;
                margin-top: 20px;
                cursor: pointer;
            }

        </style>

    </head>

    <body>

        <div class="card">

            <h2>ADMIN LOGIN</h2>

            <form method="POST">

                <label>Username</label>

                <input
                    type="text"
                    name="username"
                    required
                >

                <label>Password</label>

                <input
                    type="password"
                    name="password"
                    required
                >

                <button type="submit">
                    LOGIN
                </button>

            </form>

        </div>

    </body>
    </html>
    """)


# =========================
# ADMIN LOGOUT
# =========================
@app.route("/logout")
def logout():

    session.clear()

    return redirect(url_for("login"))


# =========================
# VIEW ASSET
# =========================
@app.route("/asset/<asset_id>")
def asset_details(asset_id):

    conn = get_db()

    asset = conn.execute(
        "SELECT * FROM assets WHERE asset_id = ?",
        (asset_id,)
    ).fetchone()

    conn.close()

    if asset is None:
        return "Asset not found", 404

    return render_template_string("""
    <!DOCTYPE html>
    <html>

    <head>

        <meta name="viewport"
              content="width=device-width, initial-scale=1">

        <title>Asset Details</title>

        <style>

            body {
                font-family: Arial, sans-serif;
                background: #f3f4f6;
                margin: 0;
                padding: 20px;
            }

            .card {
                max-width: 500px;
                margin: auto;
                background: white;
                padding: 25px;
                border-radius: 15px;
                box-shadow: 0 3px 12px rgba(0,0,0,0.15);
            }

            h2 {
                text-align: center;
                margin-bottom: 25px;
            }

            .row {
                padding: 13px 0;
                border-bottom: 1px solid #ddd;
            }

            .label {
                font-weight: bold;
            }

        </style>

    </head>

    <body>

        <div class="card">

            <h2>ASSET DETAILS</h2>

            <div class="row">
                <span class="label">Asset ID:</span>
                {{ asset["asset_id"] }}
            </div>

            <div class="row">
                <span class="label">Asset Type:</span>
                {{ asset["asset_type"] }}
            </div>

            <div class="row">
                <span class="label">Model:</span>
                {{ asset["model"] }}
            </div>

            <div class="row">
                <span class="label">Serial No:</span>
                {{ asset["serial_no"] }}
            </div>

            <div class="row">
                <span class="label">Status:</span>
                {{ asset["status"] }}
            </div>

            <div class="row">
                <span class="label">Assigned To:</span>
                {{ asset["assigned_to"] }}
            </div>

        </div>

    </body>

    </html>
    """, asset=asset)


# =========================
# ADMIN DASHBOARD
# =========================
@app.route("/admin")
@login_required
def admin():

    conn = get_db()

    assets = conn.execute(
        "SELECT * FROM assets ORDER BY asset_id"
    ).fetchall()

    conn.close()

    return render_template_string("""
    <!DOCTYPE html>
    <html>

    <head>

        <meta name="viewport"
              content="width=device-width, initial-scale=1">

        <title>Asset Admin</title>

        <style>

            body {
                font-family: Arial, sans-serif;
                margin: 20px;
                background: #f5f5f5;
            }

            h1 {
                text-align: center;
            }

            .top {
                text-align: right;
                margin-bottom: 15px;
            }

            table {
                width: 100%;
                border-collapse: collapse;
                background: white;
            }

            th, td {
                padding: 10px;
                border: 1px solid #ddd;
                text-align: left;
            }

            th {
                background: #eee;
            }

            a {
                text-decoration: none;
            }

            .logout {
                padding: 8px 12px;
                background: #ddd;
                border-radius: 5px;
            }

        </style>

    </head>

    <body>

        <h1>Asset Management</h1>

        <div class="top">
            <a class="logout" href="/logout">
                Logout
            </a>
        </div>

        <table>

            <tr>
                <th>Asset ID</th>
                <th>Model</th>
                <th>Status</th>
                <th>Assigned To</th>
                <th>Action</th>
            </tr>

            {% for asset in assets %}

            <tr>

                <td>{{ asset["asset_id"] }}</td>

                <td>{{ asset["model"] }}</td>

                <td>{{ asset["status"] }}</td>

                <td>{{ asset["assigned_to"] }}</td>

                <td>
                    <a href="/admin/edit/{{ asset['asset_id'] }}">
                        Edit
                    </a>
                </td>

            </tr>

            {% endfor %}

        </table>

    </body>

    </html>
    """, assets=assets)


# =========================
# EDIT ASSET
# =========================
@app.route("/admin/edit/<asset_id>", methods=["GET", "POST"])
@login_required
def edit_asset(asset_id):

    conn = get_db()

    asset = conn.execute(
        "SELECT * FROM assets WHERE asset_id = ?",
        (asset_id,)
    ).fetchone()

    if asset is None:
        conn.close()
        return "Asset not found", 404

    if request.method == "POST":

        status = request.form["status"]
        assigned_to = request.form["assigned_to"]

        conn.execute("""
            UPDATE assets
            SET status = ?, assigned_to = ?
            WHERE asset_id = ?
        """, (
            status,
            assigned_to,
            asset_id
        ))

        conn.commit()
        conn.close()

        return redirect(url_for("admin"))

    conn.close()

    return render_template_string("""
    <!DOCTYPE html>
    <html>

    <head>

        <meta name="viewport"
              content="width=device-width, initial-scale=1">

        <title>Edit Asset</title>

        <style>

            body {
                font-family: Arial, sans-serif;
                background: #f5f5f5;
                padding: 20px;
            }

            .card {
                max-width: 450px;
                margin: auto;
                background: white;
                padding: 25px;
                border-radius: 15px;
            }

            label {
                display: block;
                margin-top: 15px;
                font-weight: bold;
            }

            input {
                width: 100%;
                padding: 10px;
                margin-top: 5px;
                box-sizing: border-box;
            }

            button {
                margin-top: 20px;
                width: 100%;
                padding: 12px;
                cursor: pointer;
            }

        </style>

    </head>

    <body>

        <div class="card">

            <h2>Edit Asset</h2>

            <p>
                <b>Asset ID:</b>
                {{ asset["asset_id"] }}
            </p>

            <p>
                <b>Model:</b>
                {{ asset["model"] }}
            </p>

            <p>
                <b>Serial No:</b>
                {{ asset["serial_no"] }}
            </p>

            <form method="POST">

                <label>Status</label>

                <input
                    type="text"
                    name="status"
                    value="{{ asset['status'] }}"
                    required
                >

                <label>Assigned To</label>

                <input
                    type="text"
                    name="assigned_to"
                    value="{{ asset['assigned_to'] }}"
                >

                <button type="submit">
                    SAVE CHANGES
                </button>

            </form>

        </div>

    </body>

    </html>
    """, asset=asset)


# =========================
# START SERVER
# =========================
if __name__ == "__main__":

    app.run(
        host="0.0.0.0",
        port=5000
    )