import os
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader


# =========================================================
# SETTINGS
# =========================================================

QR_FOLDER = "QR_Codes"
LABEL_FOLDER = "Labels"

# Physical label size
LABEL_MM = 35

# A4 size
PAGE_WIDTH, PAGE_HEIGHT = A4

# Convert millimetres to PDF points
MM = 72 / 25.4

LABEL_SIZE = LABEL_MM * MM


# =========================================================
# A4 LAYOUT
# =========================================================

# 5 columns × 8 rows
COLUMNS = 5
ROWS = 8

LABELS_PER_PAGE = COLUMNS * ROWS


# Center the complete label grid on A4
GRID_WIDTH = COLUMNS * LABEL_SIZE
GRID_HEIGHT = ROWS * LABEL_SIZE

LEFT_MARGIN = (PAGE_WIDTH - GRID_WIDTH) / 2
TOP_MARGIN = (PAGE_HEIGHT - GRID_HEIGHT) / 2


# =========================================================
# CREATE LABELS FOLDER
# =========================================================

os.makedirs(LABEL_FOLDER, exist_ok=True)


# =========================================================
# GET QR FILES
# =========================================================

qr_files = []

for filename in os.listdir(QR_FOLDER):

    if filename.lower().endswith(".png"):

        qr_files.append(
            filename
        )


# Sort by Asset ID
qr_files.sort()


if not qr_files:

    print("❌ No QR code PNG files found!")

    print(
        f"Check this folder: {os.path.abspath(QR_FOLDER)}"
    )

    exit()


print(
    f"Found {len(qr_files)} QR codes."
)

print(
    f"A4 layout: {COLUMNS} columns × {ROWS} rows"
)

print(
    f"Labels per A4: {LABELS_PER_PAGE}"
)

print()


# =========================================================
# CREATE INDIVIDUAL A4 PDF FILES
# =========================================================

page_number = 1


for start in range(
    0,
    len(qr_files),
    LABELS_PER_PAGE
):

    page_files = qr_files[
        start:start + LABELS_PER_PAGE
    ]


    output_file = os.path.join(
        LABEL_FOLDER,
        f"Labels_Page_{page_number:02d}.pdf"
    )


    # Create A4 PDF
    pdf = canvas.Canvas(
        output_file,
        pagesize=A4
    )


    # -----------------------------------------------------
    # PLACE LABELS
    # -----------------------------------------------------

    for index, filename in enumerate(
        page_files
    ):

        column = index % COLUMNS

        row = index // COLUMNS


        # X position
        x = (
            LEFT_MARGIN
            + column * LABEL_SIZE
        )


        # Y position
        y = (
            PAGE_HEIGHT
            - TOP_MARGIN
            - ((row + 1) * LABEL_SIZE)
        )


        image_path = os.path.join(
            QR_FOLDER,
            filename
        )


        # Place PNG at exact 35 × 35 mm
        pdf.drawImage(

            ImageReader(image_path),

            x,
            y,

            width=LABEL_SIZE,
            height=LABEL_SIZE,

            preserveAspectRatio=True,

            anchor="c"
        )


    # Finish this A4 page
    pdf.save()


    print(
        f"Created: {output_file}"
    )


    page_number += 1


# =========================================================
# DONE
# =========================================================

total_pages = page_number - 1


print()
print("========================================")
print("✅ A4 LABEL SHEETS CREATED")
print("========================================")

print(
    f"Total QR codes : {len(qr_files)}"
)

print(
    f"Total A4 sheets: {total_pages}"
)

print(
    f"Label size     : {LABEL_MM} × {LABEL_MM} mm"
)

print(
    f"Labels per A4  : {LABELS_PER_PAGE}"
)

print(
    f"Output folder  : {os.path.abspath(LABEL_FOLDER)}"
)