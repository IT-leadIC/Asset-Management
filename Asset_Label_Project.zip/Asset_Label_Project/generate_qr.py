import os
import pandas as pd
import qrcode
from PIL import Image, ImageDraw, ImageFont

EXCEL_FILE = "IT_Assets.xlsx"
OUTPUT_FOLDER = "QR_Codes"
LOGO_FILE = "logo.png"

SERVER_IP = "172.16.30.41"
PORT = 5000

# QR and label sizes
QR_SIZE = 400
LABEL_WIDTH = 400
LABEL_HEIGHT = 460

# Logo size inside QR
LOGO_SIZE = 70

os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# --------------------------------------------------
# Check logo
# --------------------------------------------------

if not os.path.exists(LOGO_FILE):
    print("ERROR: logo.png not found!")
    print("Place logo.png in:")
    print(os.getcwd())
    exit()

logo = Image.open(LOGO_FILE).convert("RGBA")

# --------------------------------------------------
# Read Excel
# --------------------------------------------------

df = pd.read_excel(EXCEL_FILE, header=1)

# --------------------------------------------------
# Font
# --------------------------------------------------

try:
    font = ImageFont.truetype("arialbd.ttf", 32)
except:
    font = ImageFont.load_default()

# --------------------------------------------------
# Generate QR for every asset
# --------------------------------------------------

count = 0

for _, row in df.iterrows():

    asset_id = str(row["Asset No"]).strip()

    if not asset_id or asset_id.lower() == "nan":
        continue

    # Asset URL
    asset_url = f"http://{SERVER_IP}:{PORT}/asset/{asset_id}"

    # --------------------------------------------------
    # Generate QR
    # --------------------------------------------------

    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=4
    )

    qr.add_data(asset_url)
    qr.make(fit=True)

    qr_image = qr.make_image(
        fill_color="black",
        back_color="white"
    ).convert("RGB")

    qr_image = qr_image.resize(
        (QR_SIZE, QR_SIZE),
        Image.Resampling.NEAREST
    )

    # --------------------------------------------------
    # Add LeadIC logo INSIDE QR
    # --------------------------------------------------

    logo_copy = logo.copy()

    logo_copy.thumbnail(
        (LOGO_SIZE, LOGO_SIZE),
        Image.Resampling.LANCZOS
    )

    # White background behind logo
    logo_bg = Image.new(
        "RGB",
        (LOGO_SIZE + 20, LOGO_SIZE + 20),
        "white"
    )

    logo_x = (logo_bg.width - logo_copy.width) // 2
    logo_y = (logo_bg.height - logo_copy.height) // 2

    logo_bg.paste(
        logo_copy,
        (logo_x, logo_y),
        logo_copy
    )

    # Center logo
    qr_x = (QR_SIZE - logo_bg.width) // 2
    qr_y = (QR_SIZE - logo_bg.height) // 2

    qr_image.paste(
        logo_bg,
        (qr_x, qr_y)
    )

    # --------------------------------------------------
    # Create label
    # --------------------------------------------------

    label = Image.new(
        "RGB",
        (LABEL_WIDTH, LABEL_HEIGHT),
        "white"
    )

    qr_position_x = (LABEL_WIDTH - QR_SIZE) // 2

    label.paste(
        qr_image,
        (qr_position_x, 10)
    )

    # --------------------------------------------------
    # Asset ID below QR
    # --------------------------------------------------

    draw = ImageDraw.Draw(label)

    bbox = draw.textbbox(
        (0, 0),
        asset_id,
        font=font
    )

    text_width = bbox[2] - bbox[0]

    text_x = (LABEL_WIDTH - text_width) // 2
    text_y = QR_SIZE + 25

    draw.text(
        (text_x, text_y),
        asset_id,
        fill="black",
        font=font
    )

    # --------------------------------------------------
    # Save individual PNG
    # --------------------------------------------------

    output_file = os.path.join(
        OUTPUT_FOLDER,
        f"{asset_id}.png"
    )

    label.save(
        output_file,
        dpi=(300, 300)
    )

    count += 1

    print(f"Generated: {asset_id}")

print()
print("========================================")
print(f"SUCCESS: {count} QR labels generated")
print("========================================")
print(f"Folder: {os.path.abspath(OUTPUT_FOLDER)}")